# terkey
Termux keys shortcut

# usage
$pkg install python<br>
$pkg install git<br>
$git clone https://github.com/karjok/no hoax trl99<br>
$cd no hoax trl99<br>
$python no hoax trl99.py


